import { cn as a, cm as c } from "./index-DOhyRcjo.mjs";
export {
  a as startMockingNotes,
  c as startMockingSocial
};
